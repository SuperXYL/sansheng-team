# 三省六部智能体团队（sansheng-team）

以唐朝三省六部制为蓝本的多智能体协作专家团：中书草拟、门下封驳与交付质检、尚书派单并派发 Skill、六部并行执行，吏部兼起居注存记忆、刑部兼御史辨幻觉，决策/审核/执行三权制衡。

## 类型

Team 型（多角色协作团队）

## 编制

| 机构 | 成员 | Agent ID | 职责 |
|------|------|----------|------|
| 中书省 | 墨成章（主理人） | sansheng-team-team-lead | 需求→提示词转换、草拟诏书（仅提案权）、总编排、复旨 |
| 门下省 | 杜渐微 | decree-reviewer | 七维审核封驳（事实/逻辑/资源/风险/合规/需求/格式）、**交付质检**、画押 |
| 尚书省 | 程必行 | execution-coordinator | 任务拆解、**Skill 派发**、分派六部并行、**汇总整合/超时管控** |
| 吏部 | 任得贤 | personnel-minister | 组织分工、权限人事、提示词管理、用户档案、**起居注**（记忆归档检索） |
| 户部 | 钱有度 | revenue-minister | 数据统计、指标测算、RAG 检索、数据库查询、表格处理、信息提取 |
| 礼部 | 文彬彬 | rites-minister | 文书格式、文案润色、改写翻译、摘要、模板规范 |
| 兵部 | 武思危 | defense-minister | 安全防护、风险预案、**联网搜索、API 调用、自动化操作** |
| 刑部 | 邢无冤 | justice-minister | 合规审查、质量校验、**代码质检/调试/漏洞扫描**、**御史台**（幻觉核查） |
| 工部 | 鲁构之 | works-minister | 工程实现、编码构建、**图表生成、思维导图、文档组装** |

## 工作流程

每道旨意按固定链路流转并全程留痕：
**中书草拟 → 门下审核（封驳则重拟）→ 尚书分派（含 Skill 派发）→ 六部并行执行 → 刑部核验（含御史核幻觉）→ 门下交付质检 → 吏部起居注归档 → 复旨**

## 使用示例

- 朕下一道旨意，请三省六部依制办理：
- 着刑部核查该结论是否掺杂 AI 幻觉
- 着吏部整理并备份朕的记忆与习惯

## 附带 Skill

- `skills/sansheng-protocol`：三省六部协作协议（诏书格式、封驳格式、交付质检格式、六部归口与 Skill 映射、流程规则）

## 头像

头像已自动生成在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

将专家包目录放到专家目录下：

```
C:\Users\S\.workbuddy\plugins\marketplaces\my-experts\plugins\sansheng-team\
```

然后运行注册命令使其可见：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
python3 scripts/package_expert.py <expert-dir>
```
