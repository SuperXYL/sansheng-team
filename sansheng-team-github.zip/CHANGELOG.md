# Changelog

## v1.3.0 — 2026-11-06

Protocol v2: absorbed the three-model review (Kimi-K3.1-Pro / WorkBuddy / GLM).

### Added
- **L0–L3 risk routing** — deterministic triage; L0 answers skip the pipeline entirely
- **TaskContract** — machine-readable task spec (goal, `user_raw` pass-through, output schema, acceptance tests, budget, tool permissions)
- **DAG state machine** — `pending/running/blocked/succeeded/failed/cancelled`, checkpoints, cancel propagation, idempotent external writes, dead-letter list
- **Budget circuit breaker** — 80% warn / 100% cut; result caching for repeated subtasks
- **Veto escalation** — max 2 rejections, then a human decision point (no infinite loops, no forced release)
- **HITL gates** — explicit human approval for publish/delete/payments/production writes; PLC & live-hardware always blocked by default
- **Conflict arbitration order** — safety > compliance > facts > format
- **Memory governance** — source/time/confidence/TTL per memory item, redaction, versioned conflicts, 30-day decay, feedback loop after final report
- **Model tiering guidance** — light models for routing/format, strong models for drafting/review
- **Parallel verification** — Justice (facts/code) ∥ Menxia (requirements/release), RACI-split
- **Dynamic execution pool** — spawn only 1–4 ministries per task

### Changed
- Menxia review depth now scales with risk level (L2 full 7-dim, L1 sampled, L0 exempt)
- Six ministries redefined as capability labels + tool permissions, not a mandatory roll call
- Relay handoffs pass artifact references + summaries, not full transcripts

### Adapters
- WorkBuddy expert-team package (native)
- Codex CLI (`AGENTS.md` + role prompts)
- DeepSeek Harness (`dsh-plugin.json` + role prompts)

## v1.2.0 — 2026-11-06
- Duty alignment pass against a standard multi-agent spec (proposal-only authority, 7-dim review, aggregation, RAG/table extraction, translation, external actions, code QA, charts/assembly)
- Phase 0 pre-triage (green channel)

## v1.1.0 — 2026-11-06
- Memory Recorder merged into Personnel; Censorate (hallucination) merged into Justice
- Secretariat gains skill dispatch; Menxia gains delivery inspection

## v1.0.0 — 2026-11-06
- Initial team: 3 departments + 6 ministries + 2 special offices, protocol v1
