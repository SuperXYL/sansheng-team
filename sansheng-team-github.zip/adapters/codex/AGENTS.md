# Sansheng Team (三省六部) — Codex Adapter

This repository wires the **Three Departments Six Ministries** multi-agent protocol
(Tang-style checks & balances) into Codex CLI via the `AGENTS.md` convention.

## How it works

1. Read [`../PROTOCOL.md`](../PROTOCOL.md) — the platform-neutral protocol (TaskContract,
   L0–L3 risk routing, DAG state machine, budget circuit breaker, HITL gates,
   veto escalation, memory governance).
2. Load role prompts from this directory as subagent system prompts. Each `.md`
   file is one office holder:

| File | Role | Scope |
|------|------|-------|
| `sansheng-team-team-lead.md` | 中书令 (Chief Decree Officer, lead) | Requirement → prompt, TaskContract drafting, orchestration, final report |
| `decree-reviewer.md` | 侍中 (Chancellery) | Review & veto, delivery-standard inspection, sole release authority |
| `execution-coordinator.md` | 尚书令 (Secretariat of State) | DAG dispatch, skill assignment, aggregation, budget/timeout control |
| `personnel-minister.md` | 吏部 (Personnel) | Roles/permissions, prompt management, memory governance |
| `revenue-minister.md` | 户部 (Revenue) | Data, retrieval, statistics, tables, extraction |
| `rites-minister.md` | 礼部 (Rites) | Writing, translation, summarization, formatting |
| `defense-minister.md` | 兵部 (Defense) | Security, web/API/browser actions, HITL gates |
| `justice-minister.md` | 刑部 (Justice) | Compliance, code QA, hallucination challenge |
| `works-minister.md` | 工部 (Works) | Engineering, charts, documents, assembly |

## Runtime mapping (Codex)

- Run the lead prompt in the main session (or a designated subagent).
- Spawn ministry prompts as parallel subagents (`codex exec` sessions or task
  subagents), one per dispatched task order. Only spawn 1–4 ministries per task
  (dynamic execution pool) — do not force all six.
- All cross-agent messages pass through the lead (low coupling rule).
- Respect the L0–L3 routing table in the protocol: simple questions skip the
  pipeline entirely; L3 actions (publish, delete, payments, PLC download)
  require explicit human approval before execution.

## Contract & state

- Every L1+ task must carry a `TaskContract` (see PROTOCOL.md §TaskContract),
  including `user_raw` (verbatim user request) and acceptance tests.
- Track subtask states: `pending → running → blocked → succeeded/failed/cancelled`.
  Retry once on timeout, then dead-letter. Checkpoint after each wave.

See [`../docs/REVIEW-ADOPTION.md`](../docs/REVIEW-ADOPTION.md) for what changed
after the three-model review (Kimi / WorkBuddy / GLM).
