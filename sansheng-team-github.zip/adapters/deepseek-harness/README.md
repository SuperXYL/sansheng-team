# Sansheng Team (三省六部) — DeepSeek Harness (dsh) Adapter

This adapter wires the **Three Departments Six Ministries** multi-agent protocol
into [DeepSeek Harness](https://github.com/deepseek-ai) (`dsh`) — a self-hosted,
plugin-based agent runtime (Cordis, "everything is a plugin").

## Contents

| File | Purpose |
|------|---------|
| `../PROTOCOL.md` | Platform-neutral protocol v2 (read first) |
| `sansheng-team-team-lead.md` | 中书令 lead — requirement → prompt → TaskContract → orchestration |
| `decree-reviewer.md` | 侍中 — review/veto + delivery inspection |
| `execution-coordinator.md` | 尚书令 — DAG dispatch, skill triggers, aggregation |
| `personnel-minister.md` | 吏部 — roles, prompts, memory governance |
| `revenue-minister.md` | 户部 — data/retrieval/tables |
| `rites-minister.md` | 礼部 — writing/translation/summary |
| `defense-minister.md` | 兵部 — security + external actions (HITL) |
| `justice-minister.md` | 刑部 — compliance/code QA/hallucination challenge |
| `works-minister.md` | 工部 — engineering/charts/documents |
| `dsh-plugin.json` | Plugin manifest for `dsh` plugin loading |

## Installation (dsh)

1. Copy this directory (plus `../PROTOCOL.md`) into your dsh plugins folder,
   e.g. `~/.dsh/plugins/sansheng-team/`.
2. Register the plugin manifest:

```bash
dsh plugin load ./dsh-plugin.json
dsh agent list        # verify the 9 offices appear
```

3. Or run ad-hoc without installation — pipe the role file as the system prompt:

```bash
dsh run --system-prompt ./sansheng-team-team-lead.md \
        --name zhongshu-ling "朕下一道旨意：……"
```

## Multi-agent wiring (dsh)

- The **lead** (`sansheng-team-team-lead`) is the only agent that talks to the
  user. It spawns ministry agents via `dsh agent spawn` / your orchestrator of
  choice, passing **TaskContract** YAML (see PROTOCOL.md) as the task body.
- Spawn only **1–4 ministries per task** (dynamic execution pool). The six
  ministries are capability labels, not a mandatory roll call.
- All inter-agent messages route through the lead. No direct agent-to-agent
  calls (low coupling).
- Enable the **skill-dispatch column**: each task order names the tool/skill the
  ministry should trigger (e.g. `web_search`, `code_exec`, `sheet`).

## Risk routing & HITL (mandatory)

Follow the L0–L3 table in PROTOCOL.md:

- L0 → direct answer, no pipeline.
- L1 → short chain (plan → 1-2 executors → check → integrate).
- L2 → full pipeline with review + parallel verification.
- L3 (publish / delete / payments / production writes / PLC download) → pause
  and request explicit human approval. PLC and live-hardware actions are
  **always** blocked by default.

## Budget & failure

- Set `budget.token_ceiling` and `max_rounds` in every TaskContract.
- Subtask states: `pending → running → blocked → succeeded/failed/cancelled`.
  On timeout: degrade → retry once → dead-letter. Never retry indefinitely.
- Two vetoes escalate to a human decision point; no third rewrite loop.

## Note on dsh versions

dsh is under active development (developer preview at time of writing). The
`dsh-plugin.json` manifest follows the common plugin fields (name, version,
entry, agents). If your dsh build expects a different schema, keep the `.md`
role files as-is and map them through your runtime's own agent registry —
the prompts are runtime-agnostic.
