# Three-Model Review → Adopted Changes

On 2026-11-06 the sansheng-team design (v1.2.0) was independently reviewed by
three model perspectives: **Kimi-K3.1-Pro**, **WorkBuddy (Buddy)**, and
**GLM (Z.ai)**. This document records every confirmed criticism and how
protocol v2 / team v1.3.0 adopted it.

## Consensus findings (all three models)

| # | Finding | Adopted as |
|---|---------|------------|
| 1 | Cost & latency multiply with serial stages (6–10 LLM calls per task) | L0–L3 risk routing; L0/L1 skip full pipeline; parallel verification (Phase 5 ∥ 6) |
| 2 | Fixed 9-office roll call over-spawns agents | Dynamic execution pool: 1–4 executors per task; ministries are capability labels |
| 3 | Semantic drift through relay hops | `user_raw` pass-through in TaskContract; handoffs carry artifact refs + summaries, not full text |
| 4 | Veto loop can deadlock or become a rubber stamp | Veto ≤ 2 → mandatory human decision point; mechanical format fixes don't trigger full rewrite |
| 5 | No budget cap | Budget circuit breaker (80% warn / 100% cut) + result caching |
| 6 | High-risk external actions lack a human gate | HITL gates (L3); PLC/hardware always blocked by default |

## Adopted from individual reviews

### Kimi-K3.1-Pro
| Finding | Adopted as |
|---------|------------|
| TaskContract missing (machine-readable task spec) | Full TaskContract schema in PROTOCOL.md |
| No DAG state machine / failure recovery | States + checkpoints + cancel propagation + idempotent writes + dead-letters |
| Menxia/Justice quality overlap | RACI split: Menxia = requirements/release; Justice = facts/code/security |
| Model tiering for cost | Model tiering table in PROTOCOL.md |
| Memory quality control | Memory governance (TTL, confidence, redaction) |
| Need single-agent baseline benchmarks | Roadmap item in README |

### WorkBuddy (Buddy)
| Finding | Adopted as |
|---------|------------|
| Unified working memory instead of full-text relay | Artifact references + summaries handoff rule |
| Rules-based triage (not LLM) | "分流判定用确定性规则" in routing section |
| Human confirmation points | HITL gates |
| Failure retry policy (degrade → retry ×1 → human) | DAG failure protocol |

### GLM (Z.ai)
| Finding | Adopted as |
|---------|------------|
| 2-veto dead-end undefined ("悬空分支") | Escalation to human decision point |
| Parallel-produce conflict has no arbitration | Fixed order: safety > compliance > facts > format |
| Missing HITL for sends/deletes | HITL gates |
| Feedback not written back to memory | Feedback loop in memory governance |
| Memory only grows (no TTL/decay) | TTL + 30-day decay/distillation |
| Verification tail serialized | Justice ∥ Menxia parallel check |
| Three-level triage (not binary) | L0–L3 four-level routing table |

## Not adopted (with reason)

| Suggestion | Reason |
|------------|--------|
| Replace LLM orchestration with a code scheduler entirely | Runtime-agnostic prompts are the deliverable; deterministic rules are mandated where they matter (triage, arbitration order, state machine) — a reference scheduler is on the roadmap |
| Merge Menxia + Justice into one reviewer | Violates the checks-and-balances core; fixed instead via RACI separation |

## Radar (GLM's 8-dim assessment of v1.2.0 → expected after adoption)

| Dimension | v1.2.0 | v1.3.0 target |
|-----------|:---:|:---:|
| 分权制衡 Checks & balances | 9 | 9 |
| 质量闭环 Quality loop | 8 | 9 |
| 幻觉抑制 Hallucination control | 7 | 8 |
| 成本效率 Cost efficiency | 4 | 7 |
| 响应延迟 Latency | 4 | 7 |
| 容错韧性 Fault tolerance | 3 | 7 |
| 扩展灵活 Extensibility | 5 | 8 |
| 落地完备 Implementation readiness | 4 | 8 |
