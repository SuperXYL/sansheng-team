# Sansheng Team (三省六部智能体团队)

[![Protocol](https://img.shields.io/badge/protocol-v2-blue)](PROTOCOL.md)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Adapters](https://img.shields.io/badge/adapters-3%20platforms-informational)](adapters/)

Tang-dynasty **Three Departments Six Ministries** (三省六部) multi-agent
collaboration system — decision, review, and execution separated with real
checks & balances. Nine offices, one protocol, three runtime adapters.

> 中书出令 · 门下封驳 · 尚书派工 · 六部并行 · 刑部核验 · 吏部存忆
> Draft → Veto/Approve → Dispatch → Execute in parallel → Verify → Release

## Why

Multi-agent pipelines fail in predictable ways: unbounded cost, serial
latency, semantic drift through relay hops, "LLM reviewing LLM" blind spots,
veto loops, and no human gate on dangerous actions. This project encodes the
lessons of a **three-model review** (Kimi-K3.1-Pro, WorkBuddy, GLM) into the
protocol itself — see [docs/REVIEW-ADOPTION.md](docs/REVIEW-ADOPTION.md).

## Design in one page

```
user decree
   │
   ▼
┌─ L0-L3 risk routing (deterministic) ─────────────────────────┐
│  L0: direct answer (no pipeline)                             │
│  L1: plan → 1-2 executors → deterministic checks → integrate │
│  L2: full pipeline below                                     │
│  L3: L2 + least privilege + dry-run + HUMAN APPROVAL         │
└──────────────────────────────────────────────────────────────┘
   │ L2/L3
   ▼
中书省 (Zhongshu / Secretariat) ── drafts TaskContract (machine-readable)
   │                              incl. user_raw pass-through, budget
   ▼
门下省 (Menxia / Chancellery) ──── review & veto (≤2, then HUMAN decision)
   │                              delivery-standard inspection (release)
   ▼
尚书省 (Shangshu / Dept. of State) ─ DAG dispatch + skill triggers
   │                                 1-4 executor pool (not all six)
   │                                 budget circuit breaker, dead-letters
   ▼
六部 six ministries (parallel executors, capability labels)
   │   吏部 personnel/memory · 户部 data · 礼部 writing ·
   │   兵部 security+external actions · 刑部 code QA+fact-check · 工部 engineering
   ▼
刑部核验 ∥ 门下终检 (parallel, RACI-split: facts/code vs requirements/release)
   ▼
复旨 final report: conclusions → evidence → risks (+ dead letters, budget use)
```

Key mechanisms (all specified in [PROTOCOL.md](PROTOCOL.md)):

| Mechanism | What it prevents |
|-----------|------------------|
| L0–L3 risk routing | Over-layering simple questions |
| TaskContract + `user_raw` pass-through | Semantic drift across relay hops |
| DAG state machine + checkpoints + dead-letters | Stuck/restarted pipelines |
| Budget circuit breaker (80% warn / 100% cut) | Unbounded token spend |
| Veto ≤ 2 → human decision point | Infinite rewrite loops |
| HITL gates on external/irreversible actions | Unauthorized publishes, PLC downloads |
| Conflict arbitration: safety > compliance > facts > format | Ad-hoc tradeoffs during aggregation |
| Memory governance (TTL, confidence, redaction, feedback loop) | Memory bloat & poisoned recall |

## Adapters

| Platform | Path | Entry point |
|----------|------|-------------|
| **WorkBuddy** | [`adapters/workbuddy/`](adapters/workbuddy/) | Expert-team package (`plugin.json` + 9 agent MDs + avatars + skill) |
| **Codex CLI** | [`adapters/codex/`](adapters/codex/) | [`AGENTS.md`](adapters/codex/AGENTS.md) + role prompts |
| **DeepSeek Harness (dsh)** | [`adapters/deepseek-harness/`](adapters/deepseek-harness/) | [`dsh-plugin.json`](adapters/deepseek-harness/dsh-plugin.json) + role prompts |

Role prompts are runtime-agnostic Markdown. If your runtime is not listed,
load the prompts as system prompts and follow `PROTOCOL.md` — the protocol is
the product.

## Quick start

**WorkBuddy** — copy `adapters/workbuddy/` into your experts directory and
register, or import the packaged zip.

**Codex** — drop `adapters/codex/AGENTS.md` at your repo root (or reference it);
spawn ministry prompts as subagents per the mapping table inside.

**DeepSeek Harness** —
```bash
cp -r adapters/deepseek-harness ~/.dsh/plugins/sansheng-team
dsh plugin load ~/.dsh/plugins/sansheng-team/dsh-plugin.json
```

## Layout

```
PROTOCOL.md                  # the protocol v2 (platform-neutral, authoritative)
adapters/workbuddy/          # WorkBuddy expert-team package
adapters/codex/              # AGENTS.md + 9 role prompts
adapters/deepseek-harness/   # dsh-plugin.json + 9 role prompts
docs/REVIEW-ADOPTION.md      # three-model review → adopted changes
CHANGELOG.md
LICENSE
```

## Roadmap

- Deterministic validator for TaskContract YAML
- Reference DAG scheduler (Python, single-file) with checkpoint/dead-letter
- Benchmark suite: single-agent vs full-pipeline acceptance rate / latency / cost

## License

[MIT](LICENSE) — attribution appreciated; PRs welcome.

## Acknowledgements

Reviewed by three independent model perspectives (Kimi-K3.1-Pro, WorkBuddy,
GLM) whose critiques directly shaped protocol v2. See
[docs/REVIEW-ADOPTION.md](docs/REVIEW-ADOPTION.md).
